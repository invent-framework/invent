"""
import invent
import pytest
from unittest import mock
"""


def test_foo():
    """
    Test
    """
    assert True
